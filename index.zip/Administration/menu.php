 
<div class="menu_box">
    <h5><a href="#">Cities</a></h5>
    <div class="left_menu">
        <li><a href="index.php">All Cities</a></li>
        <li><a href="add_city.php">Add Cities</a></li>
        <li><a href="countries.php">Countries</a></li>
    </div>
</div>