 
 
 <!-- footer -->
    <footer>
        <div class="container">
            <div class="footer">
                <a class="instagram" href="#"><img class="footer_icon" src="img/insta.svg" alt="icon"></a>
                <img class="line" src="img/Line.svg" alt="line">
                <a class="facebook" href="#"><img class="footer_icon" src="img/facebook.svg" alt="icon"></a>
                <img class="line" src="img/Line.svg" alt="line">
                <a class="youtube" href="#"><img class="footer_icon" src="img/youtube.svg" alt="icon"></a>
                <img class="line" src="img/Line.svg" alt="line">
                <a class="tiktok" href="#"><img class="footer_icon" src="img/tiktok.svg" alt="icon"></a>
            </div>
            <div class="footer_logo">
                <a href="index.php"><img src="img/footer_logo.png" alt="logo"></a>
            </div>
        </div>
    </footer>
    <section class="copyright">
        <div class="container">
            <div class="copyright_box">
                <div class="copy_text">
                    <p>&copy; 2022. All rights reserved</p>
                </div>
                <div class="policy">
                    <a href="terms.php">Terms Of Use</a>
                    <a href="privacy.php">Privacy Policy</a>
                    <a href="faq.php">FAQs</a>
                </div>
            </div>
        </div>
    </section>

    


    <!-- script coding -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <!-- bootstrap 5 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- owl-carousel -->
    <script src="js/owl.carousel.min.js"></script>
    <script>
        $('.owl-carousel1').owlCarousel({
            loop:true,
            margin:30,
            nav:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        })
    </script>
    <script>
        $('.owl-carousel2').owlCarousel({
            loop:true,
            margin:30,
            nav:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                },
                1200:{
                    items:4
                }
            }
        })
    </script>
    <script>
        $('.owl-carousel3').owlCarousel({
            loop:true,
            margin:30,
            nav:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        })
    </script>

    <script>
        $('.owl-carousel4').owlCarousel({
            loop:true,
            margin:30,
            nav:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                },
                1200:{
                    items:4
                }
            }
        })
    </script>
    <script>
        $('.owl-carousel_event').owlCarousel({
            loop:true,
            margin:30,
            nav:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:1
                }
            }
        })
    </script>
    <script>
        $('.owl-carousel_gallery').owlCarousel({
            loop:true,
            margin:30,
            nav:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        })
    </script>

    <!-- weather icon -->
    <script>
        $(document).ready(function(){
            $('#weaher_details').click(function () {
                if ($('#minus').is(':hidden')) {
                    $('#minus').show();
                    $('#plus').hide();
                } else {
                    $('#minus').hide();
                    $('#plus').show();
                }
            }); 
        });
    </script>
    <script>
        $(document).ready(function(){
            $('#weaher_details2').click(function () {
                if ($('#minus2').is(':hidden')) {
                    $('#minus2').show();
                    $('#plus2').hide();
                } else {
                    $('#minus2').hide();
                    $('#plus2').show();
                }
            }); 
        });
    </script>
    <script>
        $(document).ready(function(){
            $('#weaher_details3').click(function () {
                if ($('#minus3').is(':hidden')) {
                    $('#minus3').show();
                    $('#plus3').hide();
                } else {
                    $('#minus3').hide();
                    $('#plus3').show();
                }
            }); 
        });
    </script>

    <!-- magnific poup -->
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('.popup-gallery').magnificPopup({
				delegate: 'a',
				type: 'image',
				tLoading: 'Loading image #%curr%...',
				mainClass: 'mfp-img-mobile',
				gallery: {
					enabled: true,
					navigateByImgClick: true,
					preload: [0,1]
				}
			});
		});
	</script>

    <!-- faq_left_mobile  -->
    <script>
        $(document).ready(function(){
            $('#chat').click(function () {
                if ($('#white').is(':hidden')) {
                    $('#white').show();
                    $('#color').hide();
                } else {
                    $('#white').hide();
                    $('#color').show();
                }
            }); 
        });
    </script>


